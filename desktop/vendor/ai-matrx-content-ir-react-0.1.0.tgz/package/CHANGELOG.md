# Changelog

## 0.1.0 — 2026-08-23

First release: the shared Content IR RENDER layer, extracted from
matrx-frontend so the dashboard, the Chrome extension, the desktop app, and
customers building on the platform render kinds through ONE implementation
(KINDS_EVERYWHERE_PLAN §10d-A4).

- `route/kind-route` — `applyIrKindRoute`, the marker helpers, and
  `kindServerDataFromStoredValue`. Was matrx-frontend's
  `features/content-ir/react/kind-route.ts`; the registries, the resolution
  platform, and the error sink are now a `KindRouteEnv` argument, and the
  `artifact` special case became the host's `ownedTypes` option.
- `route/partial-kind-route` — `resolveProvisionalKindRender`,
  `resolveAnnouncedKindLoading`, the partial-unsafe session latch.
- `resolver/component-resolver` — `ComponentResolver`, was matrx-frontend's
  `ComponentRegistry`: compiled floor, DB override, granular per-kind repaint
  counters, cold-fetch dedupe, warm/refresh with loud recovery. Its two loaders
  and its error sink are constructor arguments.
  - **Fixed in the move:** `lastRefreshAt` used `0` as "never refreshed", so a
    host supplying a clock that starts near zero had its FIRST refresh silently
    rate-limited away. It is now explicitly nullable.
- `react/` — `KindInstanceRender`, `GenericStructuredView`, `NodeOutcomeView` /
  `RunResultView` / `DelegatedOutput`, `ProvisionalKindBoundary` /
  `ProvisionalKindFrame`, `useContentIrKindVersion`.
- `NodeOutcomeView` / `RunResultView` / `DelegatedOutput` take `fallback` as a
  RENDER FUNCTION `(output) => ReactNode`, not a node: the fallback needs the
  payload, and the only component that has read the wrapper is the view. A
  static node would force every host to re-read the wrapper — a second reader,
  which is exactly what this family exists to prevent.
- `host/` — the seam contract (`ContentIrHost`) and
  `ContentIrRenderProvider`. Reading the host outside a provider throws rather
  than defaulting: a silent default would render the wrong component for every
  kind in an app and look like a data problem for weeks.

Peer dependencies: `react >= 19` and `@ai-matrx/content-ir` 0.2.0 (exact).
